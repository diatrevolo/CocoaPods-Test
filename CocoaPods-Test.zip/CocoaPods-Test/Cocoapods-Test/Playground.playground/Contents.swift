
// Works fine
import PromiseKit

// Uncommenting below results in "no such module 'TwilioChatClient'"
import TwilioChatClient

var str = "Hello, playground"
print(str)
